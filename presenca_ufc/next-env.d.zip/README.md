Este é um projeto [Next.js](https://nextjs.org/) inicializado com o comando [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Começando

Primeiro, execute o aplicação com o seguinte comando:

```bash
npm run dev
```

Abra o [http://localhost:3000](http://localhost:3000) no navegador.

Esse projeto usa o [`next/font`](https://nextjs.org/docs/basic-features/font-optimization) para automaticamente otimizar e carregar a fonte Inter do Google Font.

Os propósitos desta aplicação são puramente acadêmicos.