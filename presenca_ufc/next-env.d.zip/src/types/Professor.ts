export type ProfessorT = {
  sub: string,
  name: string,
  isSynced: boolean,
  picture?: string
}